package com.oodlefinance.vijay.sidhu.internal.exceptions;

public class MessageSvcException extends Exception {

    private static final long serialVersionUID = 7549081949504395944L;

    public MessageSvcException(String message){
        super(message);
    }

}
