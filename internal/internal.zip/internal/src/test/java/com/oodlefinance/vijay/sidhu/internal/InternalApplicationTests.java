package com.oodlefinance.vijay.sidhu.internal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InternalApplicationTests {

    @Test
    void contextLoads() {
    }

}
