package com.oodlefinance.vijay.sidhu.external;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExternalApplicationTests {

    @Test
    void contextLoads() {
    }

}
